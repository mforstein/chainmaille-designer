export const suppliers = {
  "Chainmail Joe": [
    {
      "name": "6mm Green Anodized",
      "color": "Anodized Green"
    },
    {
      "name": "6mm Purple Anodized",
      "color": "Anodized Purple"
    }
  ],
  "The Ring Lord": [
    {
      "name": "6mm Bright Aluminum",
      "color": "Natural"
    },
    {
      "name": "6mm Blue Anodized",
      "color": "Anodized Blue"
    }
  ]
};
