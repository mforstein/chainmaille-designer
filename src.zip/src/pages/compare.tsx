import React from "react";
import dynamic from "next/dynamic";

const Canvas2DGrid = dynamic(() => import("../components/Canvas2DGrid"), {
  ssr: false,
});
const PixiGrid = dynamic(() => import("../components/PixiGrid"), {
  ssr: false,
});

export default function ComparePage() {
  return (
    <div
      style={{
        display: "flex",
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        background: "#0f172a",
        color: "#fff",
      }}
    >
      <div style={{ flex: 1, borderRight: "1px solid #333" }}>
        <h3 style={{ textAlign: "center" }}>Canvas 2D</h3>
        <Canvas2DGrid />
      </div>
      <div style={{ flex: 1 }}>
        <h3 style={{ textAlign: "center" }}>PixiJS</h3>
        <PixiGrid />
      </div>
    </div>
  );
}