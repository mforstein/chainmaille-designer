import dynamic from "next/dynamic";
import React from "react";

const PixiGrid = dynamic(() => import("../components/PixiGrid"), {
  ssr: false,
});

export default function PixiPage() {
  return (
    <div
      style={{
        background: "#0f172a",
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        color: "#fff",
      }}
    >
      <h2 style={{ marginBottom: 10 }}>🚀 PixiJS (WebGL2D) Grid Demo</h2>
      <PixiGrid />
    </div>
  );
}