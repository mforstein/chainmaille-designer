import dynamic from "next/dynamic";
import React from "react";

const Canvas2DGrid = dynamic(() => import("../components/Canvas2DGrid"), {
  ssr: false,
});

export default function CanvasPage() {
  return (
    <div
      style={{
        background: "#0f172a",
        width: "100vw",
        height: "100vh",
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        color: "#fff",
      }}
    >
      <h2 style={{ marginBottom: 10 }}>🎨 Canvas 2D Grid Demo</h2>
      <Canvas2DGrid />
    </div>
  );
}