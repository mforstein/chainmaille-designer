// src/components/PixiGrid.tsx
import React, { useEffect, useRef, useState } from "react";
import * as PIXI from "pixi.js";

const rows = 55;
const cols = 28;
const spacingX = 24;
const spacingY = 22;
const radius = 9;
const palette = ["#000", "#e11d48", "#10b981", "#3b82f6", "#f59e0b", "#fff"];

export default function PixiGrid() {
  const containerRef = useRef<HTMLDivElement>(null);
  const appRef = useRef<PIXI.Application>();
  const [fps, setFps] = useState(0);
  const [color, setColor] = useState(palette[1]);
  const paintRef = useRef<Map<string, string>>(new Map());
  const [isPainting, setIsPainting] = useState(false);

  useEffect(() => {
    const app = new PIXI.Application({
      backgroundColor: 0x0f172a,
      resizeTo: containerRef.current!,
      antialias: true,
    });
    containerRef.current!.appendChild(app.view as any);
    appRef.current = app;

    // Create container of all circles
    const grid = new PIXI.Container();
    app.stage.addChild(grid);

    const graphics = new PIXI.Graphics();
    graphics.beginFill(0xffffff);
    graphics.drawCircle(0, 0, radius);
    graphics.endFill();
    const tex = app.renderer.generateTexture(graphics);

    const sprites: PIXI.Sprite[] = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const sprite = new PIXI.Sprite(tex);
        sprite.tint = 0x334155;
        sprite.x = c * spacingX + spacingX / 2;
        sprite.y = r * spacingY + spacingY / 2;
        sprite.interactive = true;
        sprite.cursor = "crosshair";
        grid.addChild(sprite);
        sprites.push(sprite);
      }
    }

    const handlePaint = (global: PIXI.IPointData) => {
      const c = Math.floor(global.x / spacingX);
      const r = Math.floor(global.y / spacingY);
      const key = `${r},${c}`;
      const i = r * cols + c;
      if (sprites[i]) {
        sprites[i].tint = PIXI.utils.string2hex(color);
        paintRef.current.set(key, color);
      }
    };

    app.stage.eventMode = "static";
    app.stage.hitArea = app.screen;
    app.stage.on("pointerdown", (e) => {
      setIsPainting(true);
      handlePaint(e.global);
    });
    app.stage.on("pointermove", (e) => {
      if (isPainting) handlePaint(e.global);
    });
    app.stage.on("pointerup", () => setIsPainting(false));
    app.stage.on("pointerupoutside", () => setIsPainting(false));

    // FPS counter
    let last = performance.now();
    let frames = 0;
    app.ticker.add(() => {
      frames++;
      const now = performance.now();
      if (now - last > 1000) {
        setFps(frames);
        frames = 0;
        last = now;
      }
    });

    return () => {
      app.destroy(true, true);
    };
  }, [color, isPainting]);

  return (
    <div>
      <div ref={containerRef} style={{ width: "100%", height: "90vh" }} />
      <div style={{ color: "#fff", position: "absolute", top: 10, left: 10 }}>
        FPS: {fps}
      </div>
      <div style={{ marginTop: 8, display: "flex", gap: 4 }}>
        {palette.map((c) => (
          <button
            key={c}
            onClick={() => setColor(c)}
            style={{
              width: 24,
              height: 24,
              background: c,
              border: color === c ? "2px solid #fff" : "1px solid #333",
            }}
          />
        ))}
      </div>
    </div>
  );
}