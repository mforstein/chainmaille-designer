// src/components/Canvas2DGrid.tsx
import React, { useRef, useEffect, useState } from "react";

const rows = 55;
const cols = 28;
const spacingX = 24;
const spacingY = 22;
const radius = 9;
const palette = ["#000", "#e11d48", "#10b981", "#3b82f6", "#f59e0b", "#fff"];

export default function Canvas2DGrid() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [paint, setPaint] = useState<Map<string, string>>(new Map());
  const [color, setColor] = useState(palette[1]);
  const [isPainting, setIsPainting] = useState(false);
  const [fps, setFps] = useState(0);

  // Draw grid
  const draw = () => {
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x = c * spacingX + spacingX / 2;
        const y = r * spacingY + spacingY / 2;
        const key = `${r},${c}`;
        const fill = paint.get(key) ?? "#1e293b";
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.strokeStyle = "#111";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }
  };

  // Painting
  const handlePaint = (x: number, y: number) => {
    const c = Math.floor(x / spacingX);
    const r = Math.floor(y / spacingY);
    if (r < 0 || c < 0 || r >= rows || c >= cols) return;
    const key = `${r},${c}`;
    setPaint((prev) => {
      const next = new Map(prev);
      next.set(key, color);
      return next;
    });
  };

  useEffect(() => {
    draw();
  }, [paint]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let last = performance.now();
    let frames = 0;

    const loop = (now: number) => {
      frames++;
      if (now - last > 1000) {
        setFps(frames);
        frames = 0;
        last = now;
      }
      draw();
      requestAnimationFrame(loop);
    };
    loop(0);
  }, []);

  return (
    <div style={{ position: "relative" }}>
      <canvas
        ref={canvasRef}
        width={cols * spacingX}
        height={rows * spacingY}
        style={{
          border: "1px solid #333",
          touchAction: "none",
          background: "#0f172a",
        }}
        onPointerDown={(e) => {
          setIsPainting(true);
          handlePaint(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
        }}
        onPointerMove={(e) => {
          if (isPainting)
            handlePaint(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
        }}
        onPointerUp={() => setIsPainting(false)}
        onPointerLeave={() => setIsPainting(false)}
      />
      <div style={{ position: "absolute", top: 10, left: 10, color: "#fff" }}>
        FPS: {fps}
      </div>
      <div style={{ marginTop: 8, display: "flex", gap: 4 }}>
        {palette.map((c) => (
          <button
            key={c}
            onClick={() => setColor(c)}
            style={{
              width: 24,
              height: 24,
              background: c,
              border: color === c ? "2px solid #fff" : "1px solid #333",
            }}
          />
        ))}
      </div>
    </div>
  );
}