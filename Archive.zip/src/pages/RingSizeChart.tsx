// ========================================
// src/pages/RingSizeChart.tsx
// ========================================
import React, { useMemo, useState, useRef, useEffect } from "react";
import RingRenderer, {
  computeRingVarsFixedID,
  generateRingsChart,
} from "../components/RingRenderer";

// ========================================
// === Constants ===
// ========================================
const ID_OPTIONS = [
  "7/64", "1/8", "9/64", "5/32", "3/16",
  "1/4", "5/16", "3/8", "7/16", "1/2"
];
const WIRE_OPTIONS = [0.9, 1.2, 1.6, 2.0, 2.5, 3.0]; // mm
const INCH_MM = 25.4; // 1 inch = 25.4 mm

// ========================================
// === Main Component ===
// ========================================
export default function RingSizeChart() {
  const [paint, setPaint] = useState(new Map());
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  // Responsive scaling
  useEffect(() => {
    const onResize = () => {
      const w = window.innerWidth;
      const h = window.innerHeight;
      const scaleFactor = Math.min(w / 1200, h / 800);
      setScale(scaleFactor);
    };
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // ========================================
  // === Generate chart ring data ===
  // ========================================
  const { layout, chartWidth, chartHeight } = useMemo(() => {
    const rings: any[] = [];
    const cellSize = INCH_MM;
    const offsetX = -(ID_OPTIONS.length * cellSize) / 2 + cellSize / 2;
    const offsetY = -(WIRE_OPTIONS.length * cellSize) / 2 + cellSize / 2;

    WIRE_OPTIONS.forEach((wd, row) => {
      ID_OPTIONS.forEach((id, col) => {
        const v = computeRingVarsFixedID(id, wd);

        rings.push({
          row,
          col,
          x: col * cellSize + offsetX,
          y: row * cellSize + offsetY,
          innerDiameter: v.ID_mm,
          wireDiameter: v.WD_mm,
          centerSpacing: cellSize,
        });
      });
    });

    return {
      layout: rings,
      chartWidth: ID_OPTIONS.length * cellSize,
      chartHeight: WIRE_OPTIONS.length * cellSize,
    };
  }, []);

  // ========================================
  // === Generate 3D Rings w/ SpriteText ===
  // ========================================
  const ringObjs = useMemo(() => {
    return generateRingsChart({
      rows: WIRE_OPTIONS.length,
      cols: ID_OPTIONS.length,
      innerDiameter: "1/4", // placeholder, real values come from layout
      wireDiameter: 1.2,    // placeholder, real values come from layout
      centerSpacing: INCH_MM,
      layout,
    });
  }, [layout]);

  // ========================================
  // === Optional: Sample Chainmail Section ===
  // ========================================
  function createChainmailSample() {
    const rings: any[] = [];

    const idInch = 1 / 4;
    const wireMM = 1.2;
    const idMM = idInch * 25.4;
    const outerMM = idMM + 2 * wireMM;

    const pitchX = outerMM * 0.85;
    const pitchY = outerMM * 0.75;
    const rows = 4;
    const cols = 4;

    for (let row = 0; row < rows; row++) {
      const offsetX = row % 2 === 0 ? 0 : pitchX / 2;

      for (let col = 0; col < cols; col++) {
        const x = col * pitchX + offsetX;
        const y = row * pitchY;
        const tiltZ = (row + col) % 2 === 0 ? Math.PI / 3.5 : -Math.PI / 3.5;
        const tiltX = (row + col) % 2 === 0 ? 0.15 : -0.15;
        const zOffset = (row + col) % 2 === 0 ? wireMM * 0.75 : -wireMM * 0.75;

        rings.push({
          row,
          col,
          x: x + 8 * 25.4, // offset to right of chart
          y: y - 1 * 25.4, // slightly below chart
          z: zOffset,
          radius: outerMM / 2,
          innerDiameter: idMM,
          wireDiameter: wireMM,
          rotationZ: tiltZ,
          rotationX: tiltX,
        });
      }
    }
    return rings;
  }

  // ========================================
  // === Render Scene ===
  // ========================================
  return (
    <div
      ref={containerRef}
      style={{
        width: "100vw",
        height: "100vh",
        background: "#0F1115",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* === Centered Ring Size Chart === */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: `translate(-50%, -50%) scale(${scale})`,
          zIndex: 1,
        }}
      >
        <RingRenderer
          rings={ringObjs}
          params={{
            rows: WIRE_OPTIONS.length,
            cols: ID_OPTIONS.length,
            innerDiameter: 5,
            wireDiameter: 1,
            ringColor: "#BFBFBF",
            bgColor: "#0F1115",
            centerSpacing: INCH_MM,
          }}
          paint={paint}
          setPaint={setPaint}
          activeColor="#FFFFFF"
          initialPaintMode={false}
          initialRotationLocked={false}
          initialEraseMode={false}
        />
      </div>
    </div>
  );
}