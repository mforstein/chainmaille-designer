// File: src/components/RingRenderer.tsx

import React, {
  useEffect, useRef, useState, forwardRef, useImperativeHandle,
} from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
import SpriteText from "three-spritetext";

// ============================================================
// === Constants & Helper Functions ===
// ============================================================
const INCH_TO_MM = 25.4;

export function parseInchFractionToInches(v: string | number): number {
  if (typeof v === "number") return v;
  const s = v.replace(/"/g, "").trim();
  if (s.includes("/")) {
    const [num, den] = s.split("/").map(Number);
    if (!isFinite(num) || !isFinite(den) || den === 0)
      throw new Error(`Invalid inch fraction: ${v}`);
    return num / den;
  }
  const n = Number(s);
  if (!isFinite(n)) throw new Error(`Invalid inch numeric value: ${v}`);
  return n;
}

export function inchesToMm(inches: number) {
  return inches * INCH_TO_MM;
}

export function computeRingVarsFixedID(idInput: string | number, wdMm: string | number) {
  let ID_mm: number;

  if (typeof idInput === "number" && idInput > 25) {
    ID_mm = idInput;
  } else {
    const id_in = parseInchFractionToInches(idInput);
    ID_mm = inchesToMm(id_in);
  }

  const WD_mm = typeof wdMm === "number" ? wdMm : Number(wdMm);
  if (!isFinite(WD_mm)) throw new Error(`Invalid WD: ${wdMm}`);

  const OD_mm = ID_mm + 2 * WD_mm;
  const AR = ID_mm / WD_mm;

  return {
    ID_mm, WD_mm, OD_mm, AR,
    ID_mm_disp: +ID_mm.toFixed(4),
    WD_mm_disp: +WD_mm.toFixed(3),
    OD_mm_disp: +OD_mm.toFixed(4),
    AR_disp: +AR.toFixed(3),
  };
}

// ============================================================
// === Types ===
// ============================================================
export type Ring = {
  row: number;
  col: number;
  x: number;
  y: number;
  z?: number;
  radius: number;
  innerDiameter?: number;
  wireDiameter?: number;
  centerSpacing?: number;
  rotationX?: number;
  rotationY?: number;
  rotationZ?: number;
  tiltRad?: number;
  _chartLabel?: SpriteText; // optional SpriteText
};

export interface RenderParams {
  rows: number;
  cols: number;
  innerDiameter: number;
  wireDiameter: number;
  ringColor: string;
  bgColor: string;
  centerSpacing: number;
}

export type PaintMap = Map<string, string | null>;

type Props = {
  rings: Ring[];
  params: RenderParams;
  paint: PaintMap;
  setPaint: React.Dispatch<React.SetStateAction<PaintMap>>;
  initialPaintMode?: boolean;
  initialEraseMode?: boolean;
  initialRotationLocked?: boolean;
  activeColor: string;
};

export type RingRendererHandle = {
  zoomIn: () => void;
  zoomOut: () => void;
  resetView: () => void;
  toggleLock: () => void;
  setPaintMode: (on: boolean) => void;
  toggleErase: () => void;
  clearPaint: () => void;
  lock2DView: () => void;
  forceLockRotation: (locked: boolean) => void;
  getState: () => {
    paintMode: boolean;
    eraseMode: boolean;
    rotationLocked: boolean;
  };
};

// ============================================================
// === Main Component Setup ===
// ============================================================
const RingRenderer = forwardRef<RingRendererHandle, Props>(function RingRenderer(
  {
    rings,
    params,
    paint,
    setPaint,
    initialPaintMode = true,
    initialEraseMode = false,
    initialRotationLocked = true,
    activeColor,
  },
  ref
) {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene>();
  const cameraRef = useRef<THREE.PerspectiveCamera>();
  const rendererRef = useRef<THREE.WebGLRenderer>();
  const controlsRef = useRef<OrbitControls>();
  const meshesRef = useRef<THREE.Mesh[]>([]);
  const groupRef = useRef<THREE.Group>();

  const [localPaintMode, setLocalPaintMode] = useState(initialPaintMode);
  const [localEraseMode, setLocalEraseMode] = useState(initialEraseMode);
  const [rotationLocked, setRotationLocked] = useState(initialRotationLocked);

  const paintModeRef = useRef(localPaintMode);
  const eraseModeRef = useRef(localEraseMode);
  const lockRef = useRef(rotationLocked);
  const activeColorRef = useRef(activeColor);
  const paintRef = useRef(paint);

  useEffect(() => { paintModeRef.current = localPaintMode; }, [localPaintMode]);
  useEffect(() => { eraseModeRef.current = localEraseMode; }, [localEraseMode]);
  useEffect(() => { lockRef.current = rotationLocked; }, [rotationLocked]);
  useEffect(() => { activeColorRef.current = activeColor; }, [activeColor]);
  useEffect(() => { paintRef.current = paint; }, [paint]);

  const initialZRef = useRef(240);
  const initialTargetRef = useRef(new THREE.Vector3(0, 0, 0));

  // ============================================================
  // Init Scene / Renderer
  // ============================================================
  useEffect(() => {
    if (!mountRef.current) return;
    const mount = mountRef.current;

    if (rendererRef.current) {
      try {
        rendererRef.current.dispose();
        rendererRef.current.forceContextLoss();
        mount.replaceChildren();
      } catch (err) {
        console.warn("Renderer cleanup failed:", err);
      }
    }

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(params.bgColor || "#0F1115");
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, mount.clientWidth / mount.clientHeight, 0.1, 2000);
    camera.position.set(0, 0, initialZRef.current);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.domElement.style.touchAction = "none";
    mount.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    scene.add(new THREE.AmbientLight(0xffffff, 0.85));
    const dir = new THREE.DirectionalLight(0xffffff, 1.15);
    dir.position.set(4, 6, 10);
    scene.add(dir);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.screenSpacePanning = true;
    controls.enableZoom = true;
    controls.enablePan = true;
    controls.enableRotate = !initialRotationLocked;
    controls.zoomSpeed = 1.1;
    controls.touches = { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_PAN };
    controlsRef.current = controls;

    const preventTouchZoom = (e: TouchEvent) => {
      if (e.touches.length > 1) e.preventDefault();
    };
    renderer.domElement.addEventListener("touchstart", preventTouchZoom, { passive: false });
    renderer.domElement.addEventListener("touchmove", preventTouchZoom, { passive: false });

    const onResize = () => {
      const w = window.innerWidth, h = window.innerHeight;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    window.addEventListener("resize", onResize);
    onResize();

    const raycaster = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    let painting = false;
    const activePointers = new Set<number>();

    const paintAt = (clientX: number, clientY: number) => {
      const rect = renderer.domElement.getBoundingClientRect();
      ndc.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      ndc.y = -((clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(ndc, camera);
      const hits = raycaster.intersectObjects(meshesRef.current, false);
      if (hits.length > 0) {
        const key = (hits[0].object as any).ringKey as string;
        setPaint((prev) => {
          const n = new Map(prev);
          const colorToApply = eraseModeRef.current ? params.ringColor : activeColorRef.current;
          n.set(key, colorToApply);
          return n;
        });
      }
    };

    const onDown = (e: PointerEvent) => {
      e.preventDefault();
      activePointers.add(e.pointerId);
      if (activePointers.size > 1) return;
      if (paintModeRef.current) {
        painting = true;
        paintAt(e.clientX, e.clientY);
      }
    };
    const onMove = (e: PointerEvent) => {
      if (activePointers.size > 1) return;
      if (painting && paintModeRef.current) {
        e.preventDefault();
        paintAt(e.clientX, e.clientY);
      }
    };
    const onUp = (e: PointerEvent) => {
      activePointers.delete(e.pointerId);
      if (activePointers.size === 0) painting = false;
    };

    renderer.domElement.addEventListener("pointerdown", onDown);
    renderer.domElement.addEventListener("pointermove", onMove);
    renderer.domElement.addEventListener("pointerup", onUp);

    const animate = () => {
      requestAnimationFrame(animate);
      for (const m of meshesRef.current) {
        const key = (m as any).ringKey as string;
        const color = paintRef.current.get(key) || params.ringColor;
        (m.material as THREE.MeshStandardMaterial).color.set(color);
      }
      if (controlsRef.current) {
        const locked = lockRef.current;
        controlsRef.current.enableRotate = !locked;
        controlsRef.current.enablePan = !paintModeRef.current || !locked;
        controlsRef.current.update();
      }
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      window.removeEventListener("resize", onResize);
      renderer.domElement.removeEventListener("pointerdown", onDown);
      renderer.domElement.removeEventListener("pointermove", onMove);
      renderer.domElement.removeEventListener("pointerup", onUp);
      renderer.domElement.removeEventListener("touchstart", preventTouchZoom);
      renderer.domElement.removeEventListener("touchmove", preventTouchZoom);

      if (sceneRef.current) {
        sceneRef.current.traverse((obj: any) => {
          if (obj.geometry) obj.geometry.dispose();
          if (obj.material) {
            if (Array.isArray(obj.material)) obj.material.forEach(m => m.dispose());
            else obj.material.dispose();
          }
        });
        sceneRef.current.clear();
      }

      try {
        mount.removeChild(renderer.domElement);
      } catch (e) { }
      controls.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
      renderer.domElement = null as any;
      rendererRef.current = undefined;
      sceneRef.current = undefined;
    };
  }, [params.bgColor, setPaint]);

// ============================================================
// Geometry Build (fixed version — chart text detection works)
// ============================================================
useEffect(() => {
  const scene = sceneRef.current;
  if (!scene) return;

  // Cleanup previous geometry
  if (groupRef.current) {
    groupRef.current.traverse((o: any) => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) o.material.dispose();
    });
    scene.remove(groupRef.current);
    meshesRef.current = [];
  }

  const group = new THREE.Group();
  groupRef.current = group;
  const meshes: THREE.Mesh[] = [];

  rings.forEach((r) => {
    const innerVal = r.innerDiameter ?? params.innerDiameter;
    const wireVal = r.wireDiameter ?? params.wireDiameter;
    const ringRadius = innerVal / 2 + wireVal / 2;
    const tubeRadius = wireVal / 2;

    const torus = new THREE.TorusGeometry(ringRadius, tubeRadius, 32, 128);
    const mesh = new THREE.Mesh(
      torus,
      new THREE.MeshStandardMaterial({
        color: params.ringColor,
        metalness: 0.85,
        roughness: 0.25,
      })
    );

    mesh.position.set(r.x, -r.y, r.z ?? 0);
    if (typeof r.tiltRad === "number") mesh.rotation.set(0, r.tiltRad, 0);
    if (typeof r.rotationY === "number") mesh.rotation.y = r.rotationY;
    if (typeof r.rotationZ === "number") mesh.rotation.z = r.rotationZ;
    if (typeof r.rotationX === "number") mesh.rotation.x = r.rotationX;

    (mesh as any).ringKey = `${r.row ?? 0},${r.col ?? 0}`;
    meshes.push(mesh);
    group.add(mesh);

    // ✅ Attach pre-generated SpriteText labels from Chart generator only
    if ((r as any)._chartLabel instanceof SpriteText) {
      const label = (r as any)._chartLabel;
      label.material.depthTest = false;
      label.material.depthWrite = false;
      label.renderOrder = 2000;
      group.add(label);
    }
  });

  // ✅ Keep labels facing camera
  const updateLabels = () => {
    const camera = cameraRef.current;
    if (!camera || !groupRef.current) return;
    groupRef.current.traverse((obj: any) => {
      if (obj instanceof SpriteText) {
        obj.quaternion.copy(camera.quaternion);
      }
    });
    requestAnimationFrame(updateLabels);
  };
  updateLabels();

  const box = new THREE.Box3().setFromObject(group);
  const c = box.getCenter(new THREE.Vector3());
  group.position.sub(c);
  scene.add(group);
  meshesRef.current = meshes;

  console.log(`✅ Geometry built: ${rings.length} rings (labels attached where provided)`);
}, [rings, params.ringColor, params.innerDiameter, params.wireDiameter]);
  // ============================================================
  // Debug Overlay
  // ============================================================
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    const existing = scene.getObjectByName("infoGroup");
    if (existing) scene.remove(existing);

    const infoGroup = new THREE.Group();
    infoGroup.name = "infoGroup";

    const safeNum = (n: any, d = 3) =>
      typeof n === "number" && isFinite(n) ? n.toFixed(d) : "—";

    const firstRing = Array.isArray(rings) && rings.length > 0 ? rings[0] : undefined;
    const idVal = params?.innerDiameter;
    const wdVal = params?.wireDiameter;
    const rInner = firstRing?.innerDiameter;
    const rWire = firstRing?.wireDiameter;

    let spacingVal: number | undefined =
      firstRing?.centerSpacing ?? params?.centerSpacing ?? undefined;

    if (spacingVal === undefined || !isFinite(spacingVal)) {
      console.warn("❌ Missing 'centerSpacing' in JSON or parameters!");
      spacingVal = NaN;
    }

    const genInfo = (window as any).__ringDebug || {};

    const infoText: string[] = [
      "=== Debug Info ===",
      `Dialog/Params → ID: ${safeNum(idVal)}  WD: ${safeNum(wdVal)}`,
      `Ring[0] → ID: ${safeNum(rInner)}  WD: ${safeNum(rWire)}`,
      `Spacing: ${safeNum(spacingVal, 2)} mm`,
      `Conversion Guard: ${genInfo.fromGenerator ? "✅ Generated in mm" : "⚠️ Unknown conversion"}`,
    ];

    infoText.forEach((text, i) => {
      const label = new SpriteText(text);
      label.color = i === 0 ? "#AAAAAA" : "#00FFFF";
      label.textHeight = 6;
      label.material.depthTest = false;
      label.material.depthWrite = false;
      label.renderOrder = 1000;
      label.position.set(0, -i * 10, 0);
      infoGroup.add(label);
    });

    infoGroup.position.set(0, 60, 0);
    scene.add(infoGroup);

    return () => {
      scene.remove(infoGroup);
      infoGroup.traverse((obj: any) => {
        if (obj.material) obj.material.dispose?.();
        if (obj.geometry) obj.geometry.dispose?.();
      });
    };
  }, [params.innerDiameter, params.wireDiameter, rings]);

  return <div ref={mountRef} style={{ width: "100vw", height: "100vh" }} />;
});

export default RingRenderer;
// ============================================================
// === Unified ring generation engine (separate per context) ===
// ============================================================

export function toIN(valueInMM: number): number {
  return valueInMM / INCH_TO_MM;
}

/**
 * Shared low-level generator used by all modes
 */
function _generateRingsBase({
  rows,
  cols,
  ID_mm,
  WD_mm,
  OD_mm,
  centerSpacing,
  angleIn,
  angleOut,
  layout,
}: {
  rows: number;
  cols: number;
  ID_mm: number;
  WD_mm: number;
  OD_mm: number;
  centerSpacing?: number;
  angleIn?: number;
  angleOut?: number;
  layout?: any[];
}): Ring[] {
  const rings: Ring[] = [];

  for (let r = 0; r < rows; r++) {
    const tiltDeg = (r % 2 === 0 ? angleIn : angleOut) ?? 0;
    const tiltRad = THREE.MathUtils.degToRad(tiltDeg);

    for (let c = 0; c < cols; c++) {
      const jsonRing = layout?.find((el) => el.row === r && el.col === c);
      const spacingVal =
        jsonRing?.centerSpacing ??
        centerSpacing ??
        (layout as any)?.centerSpacing ??
        0;

      const x = jsonRing?.x ?? c * spacingVal;
      const y = jsonRing?.y ?? r * (spacingVal * Math.sqrt(3) / 2);
      const z = jsonRing?.z ?? 0;

      rings.push({
        row: r,
        col: c,
        x,
        y,
        z,
        innerDiameter: jsonRing?.innerDiameter ?? ID_mm,
        wireDiameter: jsonRing?.wireDiameter ?? WD_mm,
        radius: OD_mm / 2,
        tiltRad,
        centerSpacing: spacingVal,
      });
    }
  }
  return rings;
}

// ============================================================
// === Chart: inches input → convert to mm (for charts) ===
// ============================================================
export function generateRingsChart({
  rows,
  cols,
  innerDiameter, // in inches
  wireDiameter,  // in mm
  centerSpacing,
  angleIn = 25,
  angleOut = -25,
  layout,
}: {
  rows: number;
  cols: number;
  innerDiameter: string | number;
  wireDiameter: number;
  centerSpacing?: number;
  angleIn?: number;
  angleOut?: number;
  layout?: any[];
}) {
  const id_in = parseInchFractionToInches(innerDiameter);
  const ID_mm = inchesToMm(id_in);
  const WD_mm = wireDiameter;
  const OD_mm = ID_mm + 2 * WD_mm;

  // ✅ Prefer spacing from JSON layout (meta or first item), then prop, then 0
  const spacingFromLayoutMeta =
    (layout as any)?.centerSpacing ??
    (Array.isArray(layout) ? (layout[0] as any)?.centerSpacing : undefined);

  const spacingToUse =
    spacingFromLayoutMeta ??
    centerSpacing ??
    0;

  const rings = _generateRingsBase({
    rows,
    cols,
    ID_mm,
    WD_mm,
    OD_mm,
    centerSpacing: spacingToUse,
    angleIn,
    angleOut,
    layout,
  });

  // ✅ ADD SPRITE TEXT LABELS FOR CHART PAGE
  rings.forEach((r) => {
    const wd = +(r.wireDiameter ?? WD_mm).toFixed(2);
    const id = +(r.innerDiameter ?? ID_mm).toFixed(2);
    const label = new SpriteText(`${wd}mm / ${id}mm`);
    label.color = "#CCCCCC";
    label.textHeight = 2.2;
    label.position.set(r.x, -r.y - (r.wireDiameter ?? WD_mm) * 4, r.z ?? 0);
    label.center.set(0.5, 1.2);
    label.material.depthTest = false;
    label.material.depthWrite = false;
    label.renderOrder = 999;
    (r as any)._chartLabel = label; // store for renderer to attach
  });

  (window as any).__chartDebug = {
    ID_mm,
    WD_mm,
    OD_mm,
    spacing: spacingToUse,
    mode: "chart",
  };
  return rings;
}

// ============================================================
// === Designer: accepts mm directly (no conversion, no sprites) ===
// ============================================================
export function generateRingsDesigner({
  rows,
  cols,
  innerDiameter, // in mm
  wireDiameter,  // in mm
  centerSpacing,
  angleIn = 25,
  angleOut = -25,
  layout,
}: {
  rows: number;
  cols: number;
  innerDiameter: number;
  wireDiameter: number;
  centerSpacing?: number;
  angleIn?: number;
  angleOut?: number;
  layout?: any[];
}) {
  const ID_mm = innerDiameter;
  const WD_mm = wireDiameter;
  const OD_mm = ID_mm + 2 * WD_mm;

  const rings = _generateRingsBase({
    rows,
    cols,
    ID_mm,
    WD_mm,
    OD_mm,
    centerSpacing,
    angleIn,
    angleOut,
    layout,
  });

  (window as any).__ringDebug = {
    fromGenerator: true,
    sourceInner: ID_mm,
    WD_mm,
    spacing: centerSpacing,
    mode: "designer",
  };

  return rings;
}

// ============================================================
// === Tuner: mm input, includes optional debug overlays ===
// ============================================================
export function generateRingsTuner({
  rows,
  cols,
  innerDiameter, // in mm
  wireDiameter,  // in mm
  centerSpacing,
  angleIn = 25,
  angleOut = -25,
  layout,
}: {
  rows: number;
  cols: number;
  innerDiameter: number;
  wireDiameter: number;
  centerSpacing?: number;
  angleIn?: number;
  angleOut?: number;
  layout?: any[];
}) {
  const ID_mm = innerDiameter;
  const WD_mm = wireDiameter;
  const OD_mm = ID_mm + 2 * WD_mm;

  const rings = _generateRingsBase({
    rows,
    cols,
    ID_mm,
    WD_mm,
    OD_mm,
    centerSpacing,
    angleIn,
    angleOut,
    layout,
  });

  (window as any).__tunerDebug = {
    ID_mm,
    WD_mm,
    spacing: centerSpacing,
    mode: "tuner",
  };

  // Optional: dev debug overlays
  if (process.env.NODE_ENV === "development") {
    rings.forEach((r) => {
      const label = new SpriteText(`Row:${r.row},Col:${r.col}`);
      label.color = "#00FFFF";
      label.textHeight = 2;
      label.position.set(r.x, -r.y - 2, 0);
      (r as any)._debugLabel = label;
    });
  }

  return rings;
}

// ---------------------------------------------------------------------------
// 🧩 Unified exports for all pages (no duplication, proper order)
// ---------------------------------------------------------------------------

// ✅ Temporary backward compatibility for old pages
export const generateRings = generateRingsDesigner;