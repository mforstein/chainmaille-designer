import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import App from "./App";
import RingSizeChart from "./pages/RingSizeChart";
import ChainmailWeaveTuner from "./pages/ChainmailWeaveTuner";
import ChainmailWeaveAtlas from "./pages/ChainmailWeaveAtlas";
import RingTestPage from "./pages/RingTestPage";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/designer" replace />} />
        <Route path="/designer/*" element={<App />} /> {/* ✅ FIXED HERE */}
        <Route path="/chart" element={<RingSizeChart />} />
        <Route path="/weave-tuner" element={<ChainmailWeaveTuner />} />
        <Route path="/weave-atlas" element={<ChainmailWeaveAtlas />} />
        <Route path="/test" element={<RingTestPage />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);